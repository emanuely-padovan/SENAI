# -*- coding: UTF-8 -*-

print("Olá, usuário! Fiz a tabuada do 0 ao 9 para você!")
print("TABUADA DO 0 AO 9")
for i in range(0,10):
    for c in range (1,11):
        print(i,"x",c,"=", (i*c))
