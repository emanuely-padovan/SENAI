# -*- coding: UTF-8 -*-

print("Olá, usuário! Farei a impressão do 1 ao 50 e do 50 ao 1.")
print("Imprimir do 0 à 50")
for v in range(0,51):
    print(v)

print("Impressão do 50 ao 0")
for v in range(50,0,-1):
    print(v)
