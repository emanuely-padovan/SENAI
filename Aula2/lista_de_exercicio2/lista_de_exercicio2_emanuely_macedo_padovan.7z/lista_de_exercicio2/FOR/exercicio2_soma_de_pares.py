# -*- coding: UTF-8 -*-

print("Olá, usuário! Farei a soma dos números pares do 0 ao 50!")
soma = 0
for v in range(0,51):
        soma += 2 * v
print("A soma dos números é: ", soma)
