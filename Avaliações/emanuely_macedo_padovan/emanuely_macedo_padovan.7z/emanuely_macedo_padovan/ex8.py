# -*- coding: UTF-8 -*-

print('Olá, usuário! Insira um número inteiro e direi se ele é negativo ou positivo!')


while True:
    num = int(input('Insira um número: '))
    if num > 0:
        print('O número é postivo!')
    else:
        print('O número é negativo!')


