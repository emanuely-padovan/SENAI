#-*-coding: UTF-8 -*-

print("Olá, usuário! Digite um número inteiro e lhe direi se ele é par ou ímpar")
num = int(input("Digite o primeiro valor: "))

if num %2 == 0:
    print("O número que você digitou é par!")
else:
    print("O número é ímpar!")
