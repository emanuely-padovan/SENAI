#-*-coding: UTF-8 -*-

print("Olá, usuário! Digite um número e direi se ele é múltiplo de 3 ou não")
num = int(input("Digite o número: "))

if num %3 == 0:
    print("O valor é múltiplo de 3!")
else:
    print("O valor não é múltiplo de 3!")
