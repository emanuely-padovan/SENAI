#-*-coding: UTF-8 -*-

print("Olá, usuário! Digite dois números inteiros, e lhe direi qual é o maior")
num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))

if num1 > num2:
    print("O primeiro número é o maior!")
else:
    print("O segundo é o maior!")
